from .detectors import TextDetector
from .text_connect_cfg import Config
