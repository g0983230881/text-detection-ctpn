import os
import xml.etree.ElementTree as ET

def convert_xml2txt(xml_folder, txt_folder):
    if not os.path.exists(txt_folder):
        os.makedirs(txt_folder)

    for xml_file in os.listdir(xml_folder):
        if not xml_file.endswith('.xml'):
            continue
        xml_path = os.path.join(xml_folder, xml_file)
        tree = ET.parse(xml_path)
        root = tree.getroot()

        txt_lines = []
        for obj in root.findall('object'):
            bndbox = obj.find('bndbox')
            xmin = bndbox.find('xmin').text
            ymin = bndbox.find('ymin').text
            xmax = bndbox.find('xmax').text
            ymax = bndbox.find('ymax').text
            # 根據split_label.py生成座標string
            coords = f"{xmin},{ymin},{xmax},{ymin},{xmax},{ymax},{xmin},{ymax}"
            txt_lines.append(coords)

        txt_filename = 'gt_' + os.path.splitext(xml_file)[0] + '.txt'
        txt_path = os.path.join(txt_folder, txt_filename)
        with open(txt_path, 'w') as txt_file:
            for line in txt_lines:
                txt_file.write(line + '\n')

# directory = '/home/g0983230881/test/git_clone_test/text-detection-ctpn'
xml_folder = '../../lib/prepare_training_data/VOCdevkit/VOC2007/Annotations'  # XML Folder
txt_folder = '../../lib/prepare_training_data/VOCdevkit/VOC2007/txtFolder'  # store txt_folder

# directory = '/home/g0983230881/text-detection-ctpn'
# path = directory + '/lib/prepare_training_data/VOCdevkit/VOC2007/JPEGImages'
# gt_path = directory + '/lib/prepare_training_data/VOCdevkit/VOC2007/txtFolder'
convert_xml2txt(xml_folder, txt_folder)
